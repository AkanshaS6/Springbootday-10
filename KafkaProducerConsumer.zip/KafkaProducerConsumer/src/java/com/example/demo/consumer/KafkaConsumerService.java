package com.example.demo.consumer;

import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {
@KafkaListener(topics ="orders",groupId ="myGroup")
public void consumer(String message) {
	System.out.println("Consumer Received: "+message);
}
}
