package com.example.demo.producer;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducerService {
private final KafkaTemplate<String, String>kafkaTemplate;
public KafkaProducerService(KafkaTemplate<String, String>kafkaTemplate) {
	this.kafkaTemplate=kafkaTemplate;
}
	public void sendMessage(String message) {
		// TODO Auto-generated method stub
		kafkaTemplate.send("orders",message);
		System.out.println("Producer Sent: "+message);
		
	}

}
